import { Addition } from "./addition";
import { Soustraction } from "./soustraction";
import { Multiplication } from "./multiplication";
import { Division } from "./division";

export { Addition, Soustraction, Multiplication, Division };
