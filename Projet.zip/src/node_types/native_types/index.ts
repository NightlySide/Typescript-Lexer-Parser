import { Nombre } from "./nombre";
import { Booleen } from "./boolean";
import { String } from "./string";

export { Nombre, Booleen, String };
